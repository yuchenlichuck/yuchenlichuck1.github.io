---
name: Documentation request
about: Request documentation 
title: ''
labels: 'documentation'
assignees: ''
---

### Documentation Request

<!-- What scenario or tool do you feel is missing documentation? Any particular characteristic of the feature that you believe deserves to be explained further?-->

### Previous documentation

<!-- Is there any documentation that already exists for this? If so, please provide links so we can update those sources. -->

<!-- Thanks for taking the time to report this! -->