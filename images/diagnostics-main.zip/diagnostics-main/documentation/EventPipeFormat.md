Please see the [EventPipeFormat documentation in Perfview](https://github.com/Microsoft/perfview/blob/master/src/TraceEvent/EventPipe/EventPipeFormat.md)
