Installing lldb for NetBSD 
==========================

[TBD]
