Installing lldb on FreeBSD
==========================

Working in progress.

    sudo pkg install llvm39 gettext python27
