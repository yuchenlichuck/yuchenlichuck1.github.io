MacOS
=====

### MacOS (Sierra 10.12.6) Instructions

The version of lldb that comes with Xcode 9.2 will now work with SOS and the lldb plugin. We no longer have to build lldb locally.

### MacOS (High Sierra 10.13.4) Instructions

The version of lldb that comes with Xcode 9.3/9.4 swift-4.1 will now work with SOS and the lldb plugin.

### MacOS (Mojave 10.14) Instructions

There has been no testing for the version of Xcode/lldb that comes with Mojave.
